package com.jarvis.assistant

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.sin

class JarvisCoreView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    var active = false
        set(value) {
            field = value
            invalidate()
        }

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val base = minOf(width, height) * 0.22f

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = Color.rgb(53, 214, 255)
        paint.setShadowLayer(22f, 0f, 0f, Color.rgb(53, 214, 255))

        for (i in 0 until 4) {
            val r = base + i * 20f + sin(phase + i) * (if (active) 7f else 2f)
            canvas.drawCircle(cx, cy, r, paint)
        }

        paint.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT)
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(18, 50, 71)
        canvas.drawCircle(cx, cy, base * 0.62f, paint)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 5f
        paint.color = Color.rgb(232, 247, 255)
        canvas.drawCircle(cx, cy, base * 0.42f, paint)

        phase += if (active) 0.10f else 0.035f
        postInvalidateDelayed(30)
    }
}
