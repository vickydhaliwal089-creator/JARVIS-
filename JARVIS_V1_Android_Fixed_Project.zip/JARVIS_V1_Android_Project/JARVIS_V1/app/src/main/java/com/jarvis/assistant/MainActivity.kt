package com.jarvis.assistant

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.*
import android.os.Bundle
import android.speech.*
import android.speech.tts.TextToSpeech
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.*

class MainActivity : android.app.Activity(), TextToSpeech.OnInitListener {

    private lateinit var status: TextView
    private lateinit var conversation: TextView
    private lateinit var apiKey: EditText
    private lateinit var textInput: EditText
    private lateinit var mic: Button
    private lateinit var send: Button
    private lateinit var core: JarvisCoreView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var online = false
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        conversation = findViewById(R.id.conversation)
        apiKey = findViewById(R.id.apiKey)
        textInput = findViewById(R.id.textInput)
        mic = findViewById(R.id.mic)
        send = findViewById(R.id.send)
        core = findViewById(R.id.core)

        apiKey.setText(prefs.getString("api_key", ""))
        tts = TextToSpeech(this, this)

        updateConnectivity()
        registerConnectivityCallback()

        mic.setOnClickListener { startListening() }
        send.setOnClickListener {
            val q = textInput.text.toString().trim()
            if (q.isNotEmpty()) {
                textInput.text.clear()
                handleCommand(q)
            }
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 42)
        }

        append("JARVIS", "Online. Awaiting your command, Boss.")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale.US
            tts.setSpeechRate(0.95f)
        }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 42)
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Voice recognition is not available on this device, Boss.")
            return
        }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                core.active = true
                status.text = "LISTENING"
                status.setTextColor(Color.rgb(53, 214, 255))
            }
            override fun onResults(results: Bundle?) {
                core.active = false
                status.text = if (online) "ONLINE MODE" else "OFFLINE MODE"
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = list?.firstOrNull()
                if (!text.isNullOrBlank()) handleCommand(text)
            }
            override fun onError(error: Int) {
                core.active = false
                status.text = if (online) "ONLINE MODE" else "OFFLINE MODE"
                speak("I didn't catch that, Boss.")
            }
            override fun onBeginningOfSpeech() {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onRmsChanged(rmsdB: Float) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        recognizer!!.startListening(intent)
    }

    private fun handleCommand(command: String) {
        append("BOSS", command)

        val lower = command.lowercase(Locale.getDefault())
        when {
            lower == "open youtube" || lower.contains("open youtube") -> {
                openPackageOrUrl("com.google.android.youtube", "https://www.youtube.com")
            }
            lower.contains("open chrome") -> {
                openPackageOrUrl("com.android.chrome", "https://www.google.com")
            }
            lower.contains("open instagram") -> {
                openPackageOrUrl("com.instagram.android", "https://www.instagram.com")
            }
            lower.contains("what time") || lower == "time" -> {
                val now = java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
                speak("It is $now, Boss.")
            }
            lower.contains("offline test") -> {
                speak("Offline systems are operational, Boss.")
            }
            else -> askBrain(command)
        }
    }

    private fun askBrain(command: String) {
        if (!online) {
            speak("Boss, you are currently offline. I can perform offline commands, but this request needs an internet connection.")
            return
        }

        val key = apiKey.text.toString().trim()
        if (key.isEmpty()) {
            speak("Boss, online AI is not configured yet. Paste your Gemini API key in the API key box.")
            return
        }

        prefs.edit().putString("api_key", key).apply()
        core.active = true
        status.text = "THINKING"
        status.setTextColor(Color.rgb(53, 214, 255))

        Thread {
            val result = callGemini(key, command)
            runOnUiThread {
                core.active = false
                status.text = "ONLINE MODE"
                if (result.startsWith("ERROR:")) {
                    speak("Sorry Boss, I couldn't reach the AI service.")
                    append("JARVIS", result.removePrefix("ERROR:"))
                } else {
                    append("JARVIS", result)
                    speak(result)
                }
            }
        }.start()
    }

    private fun callGemini(key: String, prompt: String): String {
        return try {
            val model = "gemini-2.5-flash"
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 30000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }

            val system = """
                You are JARVIS, a concise and helpful personal AI assistant.
                Address the user as "Boss". Be friendly and futuristic, but do not claim
                to have performed an action unless the Android app actually did it.
                Keep ordinary answers reasonably concise.
            """.trimIndent()

            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray()
                    .put(JSONObject().put("text", system))))
                .put("contents", JSONArray()
                    .put(JSONObject()
                        .put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", prompt)))))

            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream.bufferedReader().use { it.readText() }
            conn.disconnect()

            if (code !in 200..299) return "ERROR:$text"

            val json = JSONObject(text)
            val candidates = json.optJSONArray("candidates") ?: return "ERROR:No response."
            val parts = candidates.getJSONObject(0).getJSONObject("content").getJSONArray("parts")
            parts.getJSONObject(0).optString("text", "I received an empty response, Boss.")
        } catch (e: Exception) {
            "ERROR:${e.message ?: "Network error"}"
        }
    }

    private fun openPackageOrUrl(packageName: String, fallback: String) {
        val pm = packageManager
        val launch = pm.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            startActivity(launch)
            speak("Opening it now, Boss.")
        } else {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fallback)))
            speak("Opening it in your browser, Boss.")
        }
    }

    private fun speak(text: String) {
        append("JARVIS", text)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun append(who: String, text: String) {
        conversation.append("\n\n$who: $text")
        val scroll = findViewById<ScrollView>(R.id.scroll)
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun updateConnectivity() {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork
        val caps = cm.getNetworkCapabilities(n)
        online = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        status.text = if (online) "ONLINE MODE" else "OFFLINE MODE"
        status.setTextColor(if (online) Color.rgb(53,214,255) else Color.rgb(255,184,107))
    }

    private fun registerConnectivityCallback() {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runOnUiThread { updateConnectivity() }
            }
            override fun onLost(network: Network) {
                runOnUiThread { updateConnectivity() }
            }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                runOnUiThread { updateConnectivity() }
            }
        })
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}
